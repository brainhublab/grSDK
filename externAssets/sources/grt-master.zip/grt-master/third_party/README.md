# GRT Third Party Libraries

This directory contains third party libraries that are used by the GRT.

## Google Test
Google's unit testing framework: https://github.com/google/googletest

