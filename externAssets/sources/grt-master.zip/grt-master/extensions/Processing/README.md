##Gesture Recognition Toolkit Processing Examples

This directory contains several examples that can be used in [Processing](https://processing.org/) to communicate with the [GRT GUI](http://www.nickgillian.com/wiki/pmwiki.php/GRT/GUI) via [OSC](https://en.wikipedia.org/wiki/Open_Sound_Control).