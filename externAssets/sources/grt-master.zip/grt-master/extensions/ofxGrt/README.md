##Gesture Recognition Toolkit Openframeworks Extension

You can find the official openFrameworks wrapper for the GRT [here](https://github.com/nickgillian/ofxGrt).