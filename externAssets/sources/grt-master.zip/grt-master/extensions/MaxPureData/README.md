##ml-lib

ml-lib is a library of machine learning externals for Max and Pure Data, primarily based on the Gesture Recognition Toolkit.  It is designed to work on a variety of platforms including OS X, Windows, Linux, on Intel and ARM architectures.  ml-lib is designed and developed by Ali Momeni and Jamie Bullock and supported by Art Fab, the College of Fine Arts and The Frank-Ratchye STUDIO for Creative Inquiry at Carnegie Mellon University.

You can download ml-lib / find out more at: [https://github.com/cmuartfab/ml-lib/](https://github.com/cmuartfab/ml-lib/)