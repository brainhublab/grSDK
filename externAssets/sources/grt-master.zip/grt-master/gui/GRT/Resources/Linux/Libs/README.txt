You should copy into this folder the following boost static libraries:
libboost_chrono.a
libboost_date_time.a
libboost_signals.a
libboost_system.a
libboost_thread.a